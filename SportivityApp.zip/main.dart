import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sportivity',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Sportivity App'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<String> locations = [];
  String? selectedLocation;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchLocations();
  }

  Future<void> fetchLocations() async {
    const String apiKey = 
    'Q0dHyViMsPLpPB4hQyQ8GFK+4InUodGHCBrgtxEY21dtpnq4eCQyG4LTCCdb7Z0ZeRRNWYaOijsgaAp4/kkf0NDFSOk776GsTVphJaSRl8NRsMLCvVCZIq5W3ug5aXAUhphR7ckrI9atdT+g0kP+phvdUXlj+Jd4CxQfyywnVKg=';
    try {
      final response = await http.get(
        Uri.parse('https://www.sportivity.com/api/locations'),
        headers: {
          'Authorization': 'Bearer $apiKey',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          locations = List<String>.from(data['LocationResources'].map((location) => location['LocationName']));
          isLoading = true;
        });
      } else {
        throw Exception('Failed to load locations');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load locations: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey,
        title: Text(widget.title),
      ),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DropdownButton<String>(
                    hint: const Text('Selecteer een locatie'),
                    value: selectedLocation,
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedLocation = newValue;
                      });
                    },
                    items: locations.map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: selectedLocation != null ? () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Gekozen: $selectedLocation')),
                      );
                    } : null,
                    child: const Text('Kies locatie'),
                  ),
                ],
              ),
      ),
    );
  }
}